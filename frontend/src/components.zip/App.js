import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import SignIn from './pages/SignIn';
import './App.css';
import HomePage from './pages/HomePage';
import LandingPage from './pages/LandingPage';
// import AppointmentPage from './pages/AppointmentPage'; // Import the AppointmentPage component
import Locator from './pages/Locator';

const App = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Define the route for the home page */}
          <Route path="/" element={<HomePage />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/user" element={<LandingPage />} />
          <Route path="/appointment" element={<Locator />} /> {/* Add the AppointmentPage route */}
          
          {/* Add more routes as needed for other pages */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;
