import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart, faChevronRight } from '@fortawesome/free-solid-svg-icons';
import './Blogs.css';

const Blogs = () => {
  const [liked, setLiked] = useState([false, false, false]); // Track the liked state of each card

  const toggleLike = (index) => {
    setLiked(prev => {
      const newLiked = [...prev];
      newLiked[index] = !newLiked[index];
      return newLiked;
    });
  };

  return (
    <div className="section">
        <h2>Blogs and Articles</h2>
        <div className="card-container">
      <div className="card">
        <img src="Blogs1.png" alt="hi" />
        <div className="card-content">
          <h3>Card 1</h3>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eligendi laudantium voluptate ad nesciunt officia amet tempore fugiat, accusantium quos beatae quasi ut non deserunt vitae doloribus consequatur esse dolorum voluptatem!</p>
          <div className="actions">
            <FontAwesomeIcon
              icon={faHeart}
              className={`favorite ${liked[0] ? 'liked' : ''}`}
              onClick={() => toggleLike(0)}
            />
            <a href="#" className="btn">
              Read More
              <FontAwesomeIcon icon={faChevronRight} className="arrow-icon" />
            </a>
          </div>
        </div>
      </div>
      <div className="card">
        <img src="Blogs2.png" alt="hi" />
        <div className="card-content">
          <h3>Card 2</h3>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eligendi laudantium voluptate ad nesciunt officia amet tempore fugiat, accusantium quos beatae quasi ut non deserunt vitae doloribus consequatur esse dolorum voluptatem!</p>
          <div className="actions">
            <FontAwesomeIcon
              icon={faHeart}
              className={`favorite ${liked[1] ? 'liked' : ''}`}
              onClick={() => toggleLike(1)}
            />
            <a href="#" className="btn">
              Read More
              <FontAwesomeIcon icon={faChevronRight} className="arrow-icon" />
            </a>
          </div>
        </div>
      </div>
      <div className="card">
        <img src="Blogs3.png" alt="hi" />
        <div className="card-content">
          <h3>Card 3</h3>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eligendi laudantium voluptate ad nesciunt officia amet tempore fugiat, accusantium quos beatae quasi ut non deserunt vitae doloribus consequatur esse dolorum voluptatem!</p>
          <div className="actions">
            <FontAwesomeIcon
              icon={faHeart}
              className={`favorite ${liked[2] ? 'liked' : ''}`}
              onClick={() => toggleLike(2)}
            />
            <a href="#" className="btn">
              Read More
              <FontAwesomeIcon icon={faChevronRight} className="arrow-icon" />
            </a>
          </div>
        </div>
      </div>
    </div>
    </div>
    
  );
};

export default Blogs;
