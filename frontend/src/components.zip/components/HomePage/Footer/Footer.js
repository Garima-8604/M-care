import React from 'react';
import './Footer.css';

const Footer = () => {
 

  return (
<footer className="footer">
        <div className="footer-top">
          <div className="footer-column">
            <h3>About Us</h3>
            <p>Learn more about our mission to provide accessible maternal healthcare.</p>
          </div>
          <div className="footer-column">
            <h3>Services</h3>
            <ul>
              <li><a href="#consultation">Consultation</a></li>
              <li><a href="#care-packages">Care Packages</a></li>
            </ul>
          </div>
          <div className="footer-column">
            <h3>Contact</h3>
            <p>Email: support@mcare.org</p>
            <p>Phone: +123 456 7890</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2025 M-CARE. All Rights Reserved.</p>
        </div>
      </footer>
  );
};

export default Footer;


