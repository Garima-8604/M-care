import React from 'react';
import './VisionAndMission.css';

const VisionAndMission = () => {
 

  return (
    <section className="vision-mission-section">
        <div className="vision-box">
          <h2>Vision</h2>
          <p>
            To revolutionize maternal and child healthcare in rural and underserved areas, ensuring every mother and newborn receives quality care, support, and education regardless of their location.
          </p>
        </div>
        <div className="mission-box">
          <h2>Mission</h2>
          <p>
            Create rural healthcare hubs offering maternal care, mental health, and nutrition services, bridging gaps with telemedicine and outreach while ensuring sustainability through collaboration.
          </p>
        </div>
      </section>
  );
};

export default VisionAndMission;
