import React, { useRef } from 'react';
import './HeroSection.css';

const HeroSection = () => {
  // References for the scroll containers


  return (
    <main>
    <div className="hero-section">
      <div className="left-panel">
        <img 
          className="left-image" 
          src="Maskgroup.png" 
          alt="Mother Illustration" 
        />
        <p className="slogan">
          "Join our mission to make maternal healthcare accessible and affordable for every mother, everywhere."
        </p>
      </div>
      <div className="right-panel">
        <h1>Care for Every Mother, Health for Every Child.</h1>
        <button className="cta-button">Join Us Now</button>
      </div>
    </div>
  </main>



  );
};

export default HeroSection;



