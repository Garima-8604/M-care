import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faCalendar } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import './NavBar.css';

const NavBar = () => {
  const [profile, setProfile] = useState({
    name: '',
    photo: ''
  });

  useEffect(() => {
    // Fetch profile data from the database or API
    const fetchProfileData = async () => {
      try {
        const response = await fetch('/api/user/profile'); // Your API endpoint here
        const data = await response.json();
        setProfile({
          name: data.name,
          photo: data.photoUrl // assuming 'photoUrl' contains the image path
        });
      } catch (error) {
        console.error('Error fetching profile data:', error);
      }
    };

    fetchProfileData();
  }, []); // Empty dependency array to run only once on component mount

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <img 
          src="Maskgroup.png" 
          alt="M-CARE Logo" 
          className="logo" 
          width={50} 
          height={50} 
        />
        <span className="brand-name">M-CARE</span>
      </div>
      <ul className="nav-links">
        <li className="nav-item dropdown">
          <a href="#">Pregnancy</a>
          <div className="dropdown-menu">
            <a href="#planning">Planning</a>
            <a href="#stages">Stages</a>
            <a href="#nutrition">Nutrition</a>
          </div>
        </li>
        <li className="nav-item dropdown">
          <a href="#">Services</a>
          <div className="dropdown-menu">
            <a href="#consultation">Consultation</a>
            <a href="#care-packages">Care Packages</a>
          </div>
        </li>
        <li className="nav-item dropdown">
          <a href="#">Guides</a>
          <div className="dropdown-menu">
            <a href="#blogs">Blogs</a>
            <a href="#faq">FAQs</a>
          </div>
        </li>
        <li className="nav-item dropdown">
          <a href="#">Community</a>
          <div className="dropdown-menu">
            <a href="#forums">Forums</a>
            <a href="#support">Support Groups</a>
          </div>
        </li>
        <li className="nav-item dropdown">
          <a href="#">Help</a>
          <div className="dropdown-menu">
            <a href="#faq">FAQs</a>
            <a href="#contact">Contact</a>
          </div>
        </li>
      </ul>
      <div className="navbar-right">
      <Link to="/calendar" className="navbar-icon">
          <FontAwesomeIcon icon={faCalendar} style={{ color: "#ff6b6b", fontSize: "1.5rem" }} />
        </Link>
        <div className="navbar-profile">
          {profile.photo ? (
            <img
              src={profile.photo}
              alt="Profile"
              className="navbar-profile-img"
            />
          ) : (
            <img
              src="default-profile.jpg" // Fallback image in case photo is not available
              alt="Default Profile"
              className="navbar-profile-img"
            />
          )}
          <span className="navbar-profile-name">{profile.name || 'Yash'}</span>
        </div>

      </div>
    </nav>
  );
};

export default NavBar;
