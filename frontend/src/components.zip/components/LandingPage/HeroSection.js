import React, { useEffect, useState } from "react";
import "./HeroSection.css";


const HeroSection = () => {
  const [appointment, setAppointment] = useState(null);

  useEffect(() => {
    // Fetch data from the backend
    const fetchAppointment = async () => {
      try {
        const response = await fetch("https://your-backend-url.com/api/appointments/next");
        const data = await response.json();

        if (data && data.success) {
          setAppointment(data.appointment);
        } else {
          setAppointment(null);
        }
      } catch (error) {
        console.error("Error fetching appointment:", error);
        setAppointment(null);
      }
    };

    fetchAppointment();
  }, []);

  return (
    <div className="hero-section">
      <div className="hero-left">
        <div className="fetus-info">
          <img src="Maskgroup.png" alt="Fetus" className="fetus-img" />
          <div className="fetus-details">
            <p>12 Weeks</p>
            <p>Day 1</p>
            <p>Size: Plum</p>
          </div>
        </div>

        {appointment && (
          <div className="appointment-card">
            <div className="appointment-header">Incoming:</div>
            <div className="appointment-details">
              <p>
                <span className="calendar-icon">📅</span> Dr. {appointment.doctorName}
              </p>
              <p>Time: {appointment.time}</p>
            </div>
          </div>
        )}
      </div>

      <div className="hero-center">
        <blockquote>
          “ASIA'S MOST TRUSTED <br /> PREGNANCY HEALTHCARE PLATFORM”
        </blockquote>
      </div>

      <div className="hero-right">
        <img src="Maskgroup.png" alt="Doctor" className="circle-img" />
        <img src="Maskgroup.png" alt="Community 1" className="circle-img" />
        <img src="Maskgroup.png" alt="Community 2" className="circle-img" />
      </div>
    </div>
  );
};

export default HeroSection;
