import React, { useState } from "react";
import NavBar from "../components/LandingPage/NavBar";
import AppointmentHeader from "../components/Appointment/AppointmentHeader";
import AppointmentSearch from "../components/Appointment/AppointmentSearch";
import AppointmentMap from "../components/Appointment/AppointmentMap";
import NearbyHospitals from "../components/Appointment/NearbyHospitals"; // Import the NearbyHospitals component

const AppointmentPage = () => {
  const [location, setLocation] = useState("");

  const handleLocationChange = (newLocation) => {
    setLocation(newLocation);
  };

  return (
    <div>
      <NavBar />
      <AppointmentHeader />
      <AppointmentSearch onLocationChange={handleLocationChange} />
      <AppointmentMap location={location} />
      {/* Add the NearbyHospitals component */}
      {location && <NearbyHospitals location={location} />}
    </div>
  );
};

export default AppointmentPage;
