import React from "react";
import "./SignIn.css";

const SignIn = () => {
  return (
    <div className="signin-container">
      <div className="signin-header-container">
        <img
          src="Maskgroup.png"
          alt="M-Care Logo"
          className="signin-logo-header"
        />
        <h1 className="signin-title-header">M-CARE</h1>
      </div>
      <div className="signin-box">
        <h2 className="signin-header">Sign in</h2>

        <form className="signin-form">
          <label className="signin-label">Email</label>
          <input
            type="email"
            placeholder="Eg. name@gmail.com"
            className="signin-input"
          />

          <label className="signin-label">Password</label>
          <input
            type="password"
            placeholder="Enter password"
            className="signin-input"
          />

          <button type="submit" className="signin-button">
            Sign in
          </button>
        </form>

        <div className="signin-footer">
          <p>
            Don’t have an account? <a href="#" className="create-account-link">Create Account</a>
          </p>
        </div>

        <p className="or-divider">
  <span className="line"></span>
  OR
  <span className="line"></span>
</p>

        <button className="signin-google-button">
          <img
            src="/google-icon.svg"
            alt="Google Logo"
            className="signin-google-logo"
          />
          Sign in with Google
        </button>

        <p className="terms-text">
          By signing up, you acknowledge that you read & understand and agree to
          M-care <a href="#" className="terms-link">Terms</a> and <a href="#" className="privacy-link">Privacy Policy</a>.
        </p>
      </div>
    </div>
  );
};

export default SignIn;
