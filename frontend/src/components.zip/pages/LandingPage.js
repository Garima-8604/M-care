import React from "react";
import ProfileSection from "../components/LandingPage/ProfileSection";
import NavBar from "../components/LandingPage/NavBar";
import HeroSection from "../components/LandingPage/HeroSection";



const LandingPage = () => {
  const profileData = {
    name: "Yash",
    age: 28,
    weight: 58,
    startDate: "Dec 24, 2024",
    currentWeek: 12,
    commonIssue: "Diabetes",
    symptoms: ["Fatigue", "Morning Sickness", "Short of Breath", "Others"],
    bloodPressure: {
      sys: 120,
      dia: 80,
      pulse: 70,
    },
    sleep: {
      issues: ["Insomnia", "Disrupted Sleep"],
      totalHours: 6,
    },
    fetus: {
      size: "plum",
      length: 5.4,
    },
  };

  return (
    <div>
    <NavBar />
    <HeroSection />
    <ProfileSection profileData={profileData} />
    </div>
    
  );
};

export default LandingPage;
